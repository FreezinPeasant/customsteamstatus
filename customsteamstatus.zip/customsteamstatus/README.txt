To use this application properly, please follow the following steps.

1 : Click "Add a Game" on Steam and click "Add a Non-Steam Game..."
2 : Add the .exe from the list.
3 : Run the .exe through Steam (Click the "Play" button)

You're finished! Now the game your playing should appear as whatever you named the .exe!

(Rename the .exe to whatever you want. Eg. Up to Play. AFK, etc.)